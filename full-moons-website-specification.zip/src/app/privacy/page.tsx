export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-[var(--color-bg-primary)] py-16 text-[var(--color-text-light-primary)]">
      <div className="site-container max-w-3xl">
        <p className="eyebrow text-[var(--color-accent)]">Privacy Notice</p>
        <h1 className="hero-title mt-4 text-[clamp(2.3rem,6vw,3.8rem)]">Privacy and Data Use</h1>
        <div className="mt-8 space-y-6 text-[var(--color-text-light-secondary)]">
          <p>
            This website is an informational site for FULL MOONs Family Restaurant. It provides location details, menu-category overview and direct external links for calling,
            WhatsApp messaging and map directions.
          </p>
          <p>
            The website does not process payments, does not host user accounts and does not collect sensitive personal data through onsite forms at this stage.
          </p>
          <p>
            When you open external platforms (for example WhatsApp, Google Maps or listing pages), their own privacy policies apply.
          </p>
          <p>
            For corrections to business information shown on this site, please contact the restaurant directly using the published phone number.
          </p>
        </div>
      </div>
    </main>
  );
}

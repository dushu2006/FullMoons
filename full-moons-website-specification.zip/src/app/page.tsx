import Image from "next/image";
import Link from "next/link";
import { siteConfig } from "@/config/site";
import { GalleryLightbox } from "@/components/gallery-lightbox";
import { SectionHeading } from "@/components/section-heading";
import { SiteHeader } from "@/components/site-header";

const structuredData = {
  "@context": "https://schema.org",
  "@type": "Restaurant",
  name: siteConfig.business.name,
  address: {
    "@type": "PostalAddress",
    streetAddress: `${siteConfig.business.address.line1}, ${siteConfig.business.address.area}`,
    addressLocality: siteConfig.business.address.city,
    addressRegion: siteConfig.business.address.state,
    postalCode: siteConfig.business.address.postalCode,
    addressCountry: siteConfig.business.address.country,
  },
  telephone: "+918106907036",
  servesCuisine: ["South Indian", "North Indian", "Biryani", "Chinese", "Seafood", "Sichuan"],
  hasMenu: siteConfig.links.districtListing,
};

export default function HomePage() {
  return (
    <>
      <a
        href="#home-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[100] focus:bg-[var(--color-bg-cream)] focus:px-4 focus:py-2 focus:text-[var(--color-text-dark-primary)]"
      >
        Skip to main content
      </a>

      <SiteHeader />

      <main id="home-content" className="bg-[var(--color-bg-primary)] text-[var(--color-text-light-primary)]">
        <section id="home" className="section-space border-b border-[var(--color-border-dark)]">
          <div className="site-container grid items-center gap-10 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
            <div>
              <p className="eyebrow text-[var(--color-accent)]">{siteConfig.hero.eyebrow}</p>
              <h1 className="hero-title mt-4 max-w-[18ch] text-[var(--color-text-light-primary)]">{siteConfig.hero.title}</h1>
              <p className="mt-6 max-w-[60ch] text-[clamp(1rem,1.2vw,1.125rem)] leading-relaxed text-[var(--color-text-light-secondary)]">
                {siteConfig.hero.description}
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href={siteConfig.links.primaryCta} className="btn btn-primary">
                  Explore Menu
                </Link>
                <a href={siteConfig.links.directions} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
                  Get Directions
                </a>
              </div>
            </div>

            <div className="relative overflow-hidden border border-[var(--color-border-dark)] bg-[var(--color-bg-secondary)]">
              <Image
                src={siteConfig.hero.image.src}
                alt={siteConfig.hero.image.alt}
                width={1200}
                height={900}
                className="aspect-[5/4] h-full w-full object-cover"
                priority
                fetchPriority="high"
                sizes="(max-width: 1024px) 100vw, 52vw"
              />
            </div>
          </div>
        </section>

        <section id="about" className="section-space bg-[var(--color-bg-secondary)]">
          <div className="site-container grid gap-8 lg:grid-cols-2 lg:items-center">
            <div className="overflow-hidden border border-[var(--color-border-dark)]">
              <Image
                src={siteConfig.intro.image.src}
                alt={siteConfig.intro.image.alt}
                width={1200}
                height={900}
                className="aspect-[5/4] h-full w-full object-cover"
                loading="lazy"
                sizes="(max-width: 1024px) 100vw, 48vw"
              />
            </div>
            <div>
              <p className="eyebrow text-[var(--color-accent)]">{siteConfig.intro.eyebrow}</p>
              <h2 className="section-title mt-3 text-[var(--color-text-light-primary)]">{siteConfig.intro.title}</h2>
              <p className="mt-5 max-w-[62ch] text-base leading-relaxed text-[var(--color-text-light-secondary)]">
                {siteConfig.intro.description}
              </p>
              <p className="mt-5 rounded-sm border border-[var(--color-border-dark)] bg-[var(--color-bg-primary)] p-4 text-sm leading-relaxed text-[var(--color-muted)]">
                {siteConfig.business.sourceNote}
              </p>
            </div>
          </div>
        </section>

        <section className="section-space bg-[var(--color-bg-primary)]">
          <div className="site-container">
            <SectionHeading
              eyebrow="Featured"
              title="A Menu Worth Exploring"
              description="Selected categories from publicly listed menu sections. Individual dish availability and prices should be confirmed directly with the restaurant."
            />
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {siteConfig.featured.map((item) => (
                <article key={item.title} className="group overflow-hidden border border-[var(--color-border-dark)] bg-[var(--color-bg-secondary)]">
                  <Image
                    src={item.image}
                    alt={`Illustrative image representing ${item.title}`}
                    width={900}
                    height={650}
                    className="aspect-[4/3] h-full w-full object-cover transition duration-300 group-hover:scale-[1.02]"
                    loading="lazy"
                    sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 33vw"
                  />
                  <div className="p-5">
                    <h3 className="font-heading text-[clamp(1.4rem,2vw,1.7rem)] font-semibold text-[var(--color-text-light-primary)]">
                      {item.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-[var(--color-text-light-secondary)]">{item.description}</p>
                    <Link href="#menu" className="mt-5 inline-flex text-sm font-semibold text-[var(--color-accent)] hover:text-[var(--color-accent-deep)]">
                      Explore Menu →
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="menu" className="section-space bg-[var(--color-bg-cream)] text-[var(--color-text-dark-primary)]">
          <div className="site-container">
            <SectionHeading
              eyebrow="Menu"
              title="Menu Overview"
              theme="dark"
              description={
                <>
                  <p>
                    The website presents a category-based menu overview for quick browsing. For latest item-level pricing and real-time availability,
                    view the current listing.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-3">
                    <a href={siteConfig.links.districtListing} target="_blank" rel="noopener noreferrer" className="btn btn-dark-outline">
                      View Listed Menu
                    </a>
                  </div>
                </>
              }
            />

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {siteConfig.menuOverview.map((item) => (
                <article key={item.category} className="border border-[var(--color-border-light)] bg-white/50 p-5">
                  <h3 className="font-heading text-[clamp(1.35rem,1.8vw,1.6rem)] font-semibold text-[var(--color-text-dark-primary)]">
                    {item.category}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-[var(--color-text-dark-secondary)]">{item.notes}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="gallery" className="section-space bg-[var(--color-bg-cream)] text-[var(--color-text-dark-primary)] pt-0">
          <div className="site-container">
            <SectionHeading
              eyebrow="Gallery"
              title="Food Gallery"
              theme="dark"
              description="Images below are illustrative visuals for design preview and should be replaced with owner-approved restaurant photography before final publication."
            />
            <GalleryLightbox images={siteConfig.gallery} />
          </div>
        </section>

        <section className="section-space border-y border-[var(--color-border-dark)] bg-[var(--color-bg-secondary)]">
          <div className="site-container">
            <SectionHeading
              eyebrow="Order & Contact"
              title="Reach FULL MOONs quickly"
              description="Use your preferred channel to connect. Delivery-platform links are added once the exact listing URLs are owner-confirmed."
            />

            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              <a href={siteConfig.business.contact.phoneHref} className="action-card" aria-label="Call FULL MOONs Family Restaurant">
                <h3>Call</h3>
                <p>{siteConfig.business.contact.phoneDisplay}</p>
              </a>

              <a href={siteConfig.business.contact.whatsappHref} target="_blank" rel="noopener noreferrer" className="action-card">
                <h3>WhatsApp</h3>
                <p>Send a quick menu enquiry</p>
              </a>

              <a href={siteConfig.links.districtListing} target="_blank" rel="noopener noreferrer" className="action-card">
                <h3>District Listing</h3>
                <p>Browse currently published listing details</p>
              </a>

              <div className="action-card">
                <h3>Swiggy & Zomato</h3>
                <p>Exact listing links pending owner confirmation.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="visit-us" className="section-space bg-[var(--color-bg-primary)]">
          <div className="site-container grid gap-7 lg:grid-cols-2">
            <div>
              <SectionHeading
                eyebrow="Visit Us"
                title="Find FULL MOONs on Main Road"
                description="Use the verified address below and open directions in Google Maps for turn-by-turn navigation."
              />

              <div className="space-y-5 text-[var(--color-text-light-secondary)]">
                <div>
                  <h3 className="font-heading text-2xl font-semibold text-[var(--color-text-light-primary)]">{siteConfig.business.name}</h3>
                  <p className="mt-2 max-w-[58ch] leading-relaxed">{siteConfig.business.address.full}</p>
                </div>

                <div>
                  <p className="eyebrow text-[var(--color-accent)]">Opening Hours</p>
                  <p className="mt-1 text-sm">
                    Daily schedule not published in a fully verifiable format. Please call the restaurant for current timings.
                  </p>
                </div>

                <div className="flex flex-wrap gap-3">
                  <a href={siteConfig.links.directions} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
                    Get Directions
                  </a>
                  <a href={siteConfig.business.contact.phoneHref} className="btn btn-secondary">
                    Call Restaurant
                  </a>
                </div>
              </div>
            </div>

            <div className="overflow-hidden border border-[var(--color-border-dark)] bg-[var(--color-bg-secondary)] p-3">
              <div className="h-[320px] w-full overflow-hidden md:h-[420px]">
                <iframe
                  title="Map to FULL MOONs Family Restaurant"
                  src="https://www.google.com/maps?q=FULL+MOONs+Family+Restaurant+Main+Road+New+Gajuwaka+Gajuwaka+Visakhapatnam&output=embed"
                  className="h-full w-full border-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
              <a
                href={siteConfig.links.directions}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-flex text-sm font-semibold text-[var(--color-accent)] hover:text-[var(--color-accent-deep)]"
              >
                Open full map in Google Maps →
              </a>
            </div>
          </div>
        </section>

        <section className="section-space bg-[var(--color-bg-secondary)] py-16">
          <div className="site-container text-center">
            <p className="eyebrow mx-auto text-[var(--color-accent)]">Plan ahead</p>
            <h2 className="section-title mt-3 text-[var(--color-text-light-primary)]">Plan Your Next Visit.</h2>
            <p className="mx-auto mt-4 max-w-[62ch] text-[var(--color-text-light-secondary)]">
              Explore the menu categories, open directions and connect directly before you arrive.
            </p>
            <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
              <Link href="#menu" className="btn btn-primary">
                Explore Menu
              </Link>
              <a href={siteConfig.links.directions} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
                Get Directions
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[var(--color-border-dark)] bg-[var(--color-bg-primary)] py-12 text-[var(--color-text-light-secondary)]">
        <div className="site-container grid gap-8 md:grid-cols-3">
          <div>
            <p className="font-heading text-3xl font-semibold text-[var(--color-text-light-primary)]">FULL MOONs</p>
            <p className="mt-3 max-w-[34ch] text-sm leading-relaxed">
              Family restaurant in New Gajuwaka, Visakhapatnam with menu categories including biryanis, Indian dishes, seafood and more.
            </p>
          </div>

          <div>
            <p className="eyebrow text-[var(--color-accent)]">Navigation</p>
            <ul className="mt-4 space-y-2 text-sm">
              {siteConfig.navigation.map((item) => (
                <li key={item.href}>
                  <a href={item.href} className="hover:text-[var(--color-text-light-primary)]">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="eyebrow text-[var(--color-accent)]">Contact</p>
            <p className="mt-4 text-sm leading-relaxed">{siteConfig.business.address.full}</p>
            <a href={siteConfig.business.contact.phoneHref} className="mt-3 block text-sm hover:text-[var(--color-text-light-primary)]">
              {siteConfig.business.contact.phoneDisplay}
            </a>
            <div className="mt-3 flex flex-col gap-2 text-sm">
              <a href={siteConfig.links.districtListing} target="_blank" rel="noopener noreferrer" className="hover:text-[var(--color-text-light-primary)]">
                District Listing
              </a>
              <a href={siteConfig.links.directions} target="_blank" rel="noopener noreferrer" className="hover:text-[var(--color-text-light-primary)]">
                Google Maps Directions
              </a>
            </div>
          </div>
        </div>

        <div className="site-container mt-10 border-t border-[var(--color-border-dark)] pt-6 text-xs text-[var(--color-muted)]">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p>© {new Date().getFullYear()} FULL MOONs Family Restaurant. All rights reserved.</p>
            <a href="/privacy" aria-label="Privacy notice" className="hover:text-[var(--color-text-light-secondary)]">
              Privacy Notice
            </a>
          </div>
        </div>
      </footer>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />
    </>
  );
}

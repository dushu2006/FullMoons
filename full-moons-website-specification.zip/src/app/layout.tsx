import type { Metadata } from "next";
import { Cormorant_Garamond, Manrope } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const headingFont = Cormorant_Garamond({
  variable: "--font-heading",
  subsets: ["latin"],
  weight: ["500", "600"],
  display: "swap",
});

const bodyFont = Manrope({
  variable: "--font-body",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const metadataBase = new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000");

export const metadata: Metadata = {
  metadataBase,
  title: "FULL MOONs Family Restaurant | New Gajuwaka, Visakhapatnam",
  description:
    "Explore menu categories, contact details and directions for FULL MOONs Family Restaurant on Main Road, New Gajuwaka, Visakhapatnam.",
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "FULL MOONs Family Restaurant",
    description:
      "Family restaurant in New Gajuwaka, Visakhapatnam. Browse menu categories, contact details and directions.",
    type: "website",
    images: [
      {
        url: "/images/hero-biryani.jpg",
        width: 1200,
        height: 900,
        alt: "Illustrative biryani hero image",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "FULL MOONs Family Restaurant",
    description:
      "Family restaurant in New Gajuwaka, Visakhapatnam. Browse menu categories, contact details and directions.",
    images: ["/images/hero-biryani.jpg"],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className={`${headingFont.variable} ${bodyFont.variable} bg-[var(--color-bg-primary)] font-body text-[var(--color-text-light-primary)] antialiased`}>
        {children}
      </body>
    </html>
  );
}

export const siteConfig = {
  business: {
    name: "FULL MOONs Family Restaurant",
    shortName: "FULL MOONs",
    description:
      "Family restaurant in New Gajuwaka, Visakhapatnam, serving biryanis, Indian dishes, seafood, vegetarian options, starters and more.",
    address: {
      line1: "Door, 10, 9, 30, Main Road",
      area: "New Gajuwaka, Gajuwaka",
      city: "Visakhapatnam",
      state: "Andhra Pradesh",
      postalCode: "530026",
      country: "India",
      full: "Door, 10, 9, 30, Main Road, New Gajuwaka, Gajuwaka, Visakhapatnam, Andhra Pradesh 530026, India",
    },
    contact: {
      phoneDisplay: "+91 81069 07036",
      phoneHref: "tel:+918106907036",
      whatsappHref:
        "https://wa.me/918106907036?text=Hello%20FULL%20MOONs%20Family%20Restaurant%2C%20I%20would%20like%20to%20know%20more%20about%20your%20menu.",
    },
    sourceNote:
      "Address, listed phone number and cuisine categories are based on publicly available listing information and should be owner-verified before final publishing.",
  },
  navigation: [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Menu", href: "#menu" },
    { label: "Gallery", href: "#gallery" },
    { label: "Visit Us", href: "#visit-us" },
  ],
  links: {
    primaryCta: "#menu",
    directions:
      "https://www.google.com/maps/search/?api=1&query=FULL+MOONs+Family+Restaurant+Main+Road+New+Gajuwaka+Gajuwaka+Visakhapatnam",
    districtListing:
      "https://www.district.in/dining/visakhapatnam/full-moons-family-restaurant-gajuwaka-vizag",
    zomatoListing: null as string | null,
    swiggyListing: null as string | null,
  },
  hero: {
    eyebrow: "Main Road · New Gajuwaka · Visakhapatnam",
    title: "Discover Your Next Favourite Dish.",
    description:
      "Explore a selection of biryanis, Indian favourites and more at FULL MOONs Family Restaurant.",
    image: {
      src: "/images/hero-biryani.jpg",
      alt: "Illustrative biryani dish served in a traditional vessel",
    },
  },
  intro: {
    eyebrow: "About FULL MOONs",
    title: "Food-first dining with familiar favourites",
    description:
      "FULL MOONs Family Restaurant is publicly listed in New Gajuwaka, Visakhapatnam, with menu categories that include biryanis, chicken and mutton dishes, seafood, vegetarian options, starters, curries, rice, noodles, soups and Indian breads.",
    image: {
      src: "/images/intro-platter.jpg",
      alt: "Illustrative assortment of Indian dishes arranged on a table",
    },
  },
  featured: [
    {
      title: "Biryani",
      description: "Fragrant rice specials across veg and non-veg options.",
      image: "/images/hero-biryani.jpg",
    },
    {
      title: "Seafood",
      description: "Regional seafood preparations with bold Indian flavours.",
      image: "/images/featured-seafood.jpg",
    },
    {
      title: "Vegetarian",
      description: "Comforting vegetarian dishes, curries and sides.",
      image: "/images/featured-veg.jpg",
    },
    {
      title: "Starters",
      description: "Tandoori and pan-fried starters to begin your meal.",
      image: "/images/featured-starters.jpg",
    },
    {
      title: "Rice & Noodles",
      description: "Quick favourites from rice bowls to Indo-Chinese noodles.",
      image: "/images/featured-noodles.jpg",
    },
    {
      title: "Chicken & Mutton",
      description: "Popular gravies and dry dishes from classic meat sections.",
      image: "/images/gallery-curry.jpg",
    },
  ],
  menuOverview: [
    {
      category: "Veg",
      notes: "Vegetarian mains, sides and curries",
    },
    {
      category: "Biryani",
      notes: "Veg and non-veg biryani varieties",
    },
    {
      category: "Chicken",
      notes: "Starters, curries and rice accompaniments",
    },
    {
      category: "Mutton",
      notes: "Traditional mutton gravies and dry items",
    },
    {
      category: "Seafood",
      notes: "Fish and prawn-based preparations",
    },
    {
      category: "Starters",
      notes: "Vegetarian and non-vegetarian starters",
    },
    {
      category: "Rice and Noodles",
      notes: "Rice items, noodles and quick bowls",
    },
    {
      category: "Curries and Breads",
      notes: "Indian breads, curry bases and accompaniments",
    },
  ],
  gallery: [
    {
      src: "/images/hero-biryani.jpg",
      alt: "Illustrative biryani close-up",
    },
    {
      src: "/images/featured-seafood.jpg",
      alt: "Illustrative seafood curry close-up",
    },
    {
      src: "/images/featured-veg.jpg",
      alt: "Illustrative vegetarian platter",
    },
    {
      src: "/images/featured-starters.jpg",
      alt: "Illustrative Indian starters platter",
    },
    {
      src: "/images/gallery-bread.jpg",
      alt: "Illustrative Indian bread basket",
    },
    {
      src: "/images/gallery-rice.jpg",
      alt: "Illustrative rice and curry serving",
    },
  ],
} as const;

export type SiteConfig = typeof siteConfig;

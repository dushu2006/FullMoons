# End-to-end tests

This project includes Playwright tests for critical website journeys:

- Mobile navigation open/close and section navigation
- Gallery lightbox open/close keyboard flow
- Presence and validity of key contact/directions actions

## Run locally

1. Install browser binaries:

```bash
npx playwright install
```

2. Start the Next.js app:

```bash
npm run dev
```

3. Run tests:

```bash
npx playwright test
```

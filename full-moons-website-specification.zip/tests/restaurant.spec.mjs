import { expect, test } from "@playwright/test";

test("mobile menu opens, navigates, and closes", async ({ page }) => {
  await page.goto("/");

  const menuButton = page.getByRole("button", { name: /open menu|close menu/i });
  await expect(menuButton).toBeVisible();

  await menuButton.click();
  await expect(page.getByRole("navigation", { name: "Mobile Primary" })).toBeVisible();

  await page.getByRole("link", { name: "Menu" }).click();
  await expect(page).toHaveURL(/#menu/);
  await expect(page.getByRole("heading", { name: "Menu Overview" })).toBeVisible();
});

test("gallery lightbox opens and closes with escape", async ({ page }) => {
  await page.goto("/#gallery");

  const openImageButton = page.getByRole("button", { name: /open image 1 in gallery/i });
  await openImageButton.click();

  await expect(page.getByRole("dialog", { name: "Image gallery lightbox" })).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog", { name: "Image gallery lightbox" })).toBeHidden();
});

test("contact and directions actions are present and valid", async ({ page }) => {
  await page.goto("/#visit-us");

  const directions = page.getByRole("link", { name: "Get Directions" }).first();
  await expect(directions).toHaveAttribute("href", /google\.com\/maps/);

  const callLink = page.getByRole("link", { name: "Call Restaurant" });
  await expect(callLink).toHaveAttribute("href", /^tel:/);
});

# FULL MOONs Family Restaurant Website

Production-ready Next.js website for **FULL MOONs Family Restaurant** (New Gajuwaka, Visakhapatnam).

## Stack

- Next.js (App Router)
- TypeScript
- Tailwind CSS v4
- Playwright (critical E2E journeys)

## Local setup

```bash
npm install
npm run dev
```

Open: `http://localhost:3000`

## Production build

```bash
npm run build
npm run start
```

## Environment variables

Create/update `.env`:

```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
NEXT_PUBLIC_SITE_URL=https://your-production-domain.com
```

Notes:
- `NEXT_PUBLIC_SITE_URL` is used for canonical metadata, robots, and sitemap URLs.
- No API keys are required for the current website feature set.

## Automated browser tests

```bash
npx playwright install
npx playwright test
```

Current test coverage includes:
- Mobile menu open/close + menu navigation
- Gallery lightbox open/close keyboard flow
- Core contact and direction link validity

## Content ownership and verification checklist

Before publishing live, owner should verify:

1. Business name format and preferred capitalization
2. Final approved address line format
3. Phone and WhatsApp number
4. Swiggy and Zomato exact listing URLs
5. Daily opening hours
6. Final menu item-level names and prices
7. Owner-approved food and restaurant photography
8. Final production domain in `NEXT_PUBLIC_SITE_URL`

## Image policy in current build

- Current visuals are **illustrative food images** for design quality and layout completeness.
- Replace with owner-approved/licensed photos before final public launch.

## Maintenance notes

- Update all business data from `src/config/site.ts` (single source of truth)
- Keep links and contact details synced from the same config
- Avoid adding unverified claims (awards, ratings, testimonials)
- Re-run build and tests after any content or layout updates
